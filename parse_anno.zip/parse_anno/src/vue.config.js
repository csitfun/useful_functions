module.exports = {
  publicPath: './'
}